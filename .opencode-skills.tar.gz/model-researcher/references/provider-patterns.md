# Provider Configuration Patterns (Q4 2025 Verified)

<reference>

<constraints>
This document lists the ONLY verified configuration patterns for the current frontier model market. You MUST NOT deviate from these patterns unless authorized by deep research and user confirmation.
</constraints>

<guidelines name="builtin-providers">

## Built-in Providers

These providers are pre-configured in OpenCode. Just add the model.

### OpenAI

GPT-5.2 is the primary model family.

<examples>

#### Direct API Patterns

```jsonc
{
  "provider": {
    "openai": {
      "whitelist": ["gpt-5.2", "gpt-5.2-codex"],
      "models": {
        "gpt-5.2": {
          "limit": { "context": 400000, "output": 128000 }
        },
        "gpt-5.2-codex": {
          "limit": { "context": 400000, "output": 128000 }
        }
      }
    }
  }
}
```

#### OAuth Plugin Patterns

Models configured via OAuth plugins (e.g., `opencode-openai-codex-auth`) often have different enforced limits.

```jsonc
{
  "provider": {
    "openai": {
      "whitelist": ["gpt-5.2", "gpt-5.2-codex"],
      "models": {
        "gpt-5.2": {
          "name": "GPT 5.2 (OAuth)",
          "limit": { "context": 272000, "output": 128000 }
        },
        "gpt-5.2-codex": {
          "name": "GPT 5.2 Codex (OAuth)",
          "limit": { "context": 272000, "output": 128000 }
        }
      }
    }
  }
}
```

</examples>

### Anthropic

Claude 4.5 family is the current standard. You MUST NOT use Claude 3.5.

<examples>

```jsonc
{
  "provider": {
    "anthropic": {
      "models": {
        "claude-4-5-opus": {
          "id": "claude-4-5-opus-20251124",
          "limit": { "context": 200000, "output": 64000 }
        },
        "claude-4-5-sonnet": {
          "id": "claude-4-5-sonnet-20250929",
          "limit": { "context": 200000, "output": 64000 }
        }
      }
    }
  }
}
```

</examples>

### Google (Generative AI)

Gemini 3 family is the current standard. You MUST NOT use Gemini 1.5 or 2.

<examples>

```jsonc
{
  "provider": {
    "google": {
      "models": {
        "gemini-3-pro": {
          "limit": { "context": 1048576, "output": 64000 }
        },
        "gemini-3-flash": {
          "limit": { "context": 1048576, "output": 64000 }
        }
      }
    }
  }
}
```

</examples>

### xAI

<examples>

```jsonc
{
  "provider": {
    "xai": {
      "models": {
        "grok-4.1": {
          "limit": { "context": 256000, "output": 64000 }
        }
      }
    }
  }
}
```

</examples>

### DeepSeek

<examples>

```jsonc
{
  "provider": {
    "deepseek": {
      "models": {
        "deepseek-v3.2": {
          "name": "DeepSeek V3.2",
          "limit": { "context": 128000, "output": 32768 }
        },
        "deepseek-v3.2-speciale": {
          "name": "DeepSeek V3.2 Speciale",
          "limit": { "context": 128000, "output": 32768 }
        }
      }
    }
  }
}
```

</examples>

### Chinese Providers (OpenAI-Compatible)

<examples>

#### Zhipu (GLM)

```jsonc
{
  "provider": {
    "zhipu": {
      "npm": "@ai-sdk/openai-compatible",
      "options": { "baseURL": "https://api.z.ai/api/paas/v4" },
      "models": {
        "glm-4.7": {
          "limit": { "context": 200000, "output": 128000 }
        },
        "glm-4.6v": {
          "limit": { "context": 128000, "output": 128000 }
        }
      }
    }
  }
}
```

#### Moonshot (Kimi)

```jsonc
{
  "provider": {
    "moonshot": {
      "npm": "@ai-sdk/openai-compatible",
      "options": { "baseURL": "https://api.moonshot.cn/v1" },
      "models": {
        "kimi-k2-thinking": {
          "limit": { "context": 256000, "output": 64000 }
        },
        "kimi-k2-instruct": {
          "limit": { "context": 256000, "output": 64000 }
        }
      }
    }
  }
}
```

#### MiniMax

```jsonc
{
  "provider": {
    "minimax": {
      "npm": "@ai-sdk/openai-compatible",
      "options": { "baseURL": "https://api.minimax.chat/v1" },
      "models": {
        "minimax-m2.1": {
          "limit": { "context": 204800, "output": 128000 }
        },
        "minimax-m2": {
          "limit": { "context": 196608, "output": 65536 }
        }
      }
    }
  }
}
```

</examples>

</guidelines>

<guidelines name="aggregator-providers">

## Aggregator Providers

Route through model aggregators for access to many models.

### OpenRouter

<examples>

```jsonc
{
  "provider": {
    "openrouter": {
      "models": {
        "anthropic/claude-4-5-opus": {
          "name": "Claude 4.5 Opus (via OpenRouter)"
        },
        "openai/gpt-5.2": {
          "name": "GPT-5.2"
        },
        "moonshotai/kimi-k2-thinking": {
          "name": "Kimi K2 Thinking"
        }
      }
    }
  }
}
```

</examples>

### Together AI

<examples>

```jsonc
{
  "provider": {
    "together": {
      "models": {
        "deepseek-ai/DeepSeek-V3.2": {
          "name": "DeepSeek V3.2",
          "limit": { "context": 128000, "output": 32768 }
        },
        "mistralai/Mistral-Large-3-2512": {
          "name": "Mistral Large 3 (2512)",
          "limit": { "context": 262144, "output": 65536 }
        }
      }
    }
  }
}
```

</examples>

</guidelines>

<guidelines name="custom-providers">

## Custom Providers

### Generic OpenAI-Compatible

<examples>

```jsonc
{
  "provider": {
    "my-server": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "My Local Server",
      "options": {
        "baseURL": "http://localhost:8080/v1"
      },
      "models": {
        "my-model": {
          "name": "My Custom Model",
          "limit": { "context": 32000, "output": 4096 }
        }
      }
    }
  }
}
```

</examples>

### Ollama (Local)

<examples>

```jsonc
{
  "provider": {
    "ollama": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Ollama (local)",
      "options": {
        "baseURL": "http://localhost:11434/v1"
      },
      "models": {
        "llama3.3:70b": {
          "name": "Llama 3.3 70B",
          "limit": { "context": 128000, "output": 8192 }
        }
      }
    }
  }
}
```

</examples>

### LM Studio

<examples>

```jsonc
{
  "provider": {
    "lmstudio": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "LM Studio",
      "options": {
        "baseURL": "http://127.0.0.1:1234/v1"
      },
      "models": {
        "loaded-model": {
          "name": "Currently Loaded Model"
        }
      }
    }
  }
}
```

</examples>

### vLLM Server

<examples>

```jsonc
{
  "provider": {
    "vllm": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "vLLM Server",
      "options": {
        "baseURL": "http://localhost:8000/v1"
      },
      "models": {
        "NousResearch/Hermes-3-Llama-3.1-70B": {
          "name": "Hermes 3 70B",
          "limit": { "context": 131072, "output": 16384 }
        }
      }
    }
  }
}
```

</examples>

</guidelines>

<guidelines name="enterprise-setups">

## Enterprise Setups

### Azure OpenAI

Requires `AZURE_RESOURCE_NAME` env var and model deployment matching model name.

<examples>

```jsonc
{
  "provider": {
    "azure": {
      "models": {
        "gpt-5.2": {
          "limit": { "context": 400000, "output": 128000 }
        }
      }
    }
  }
}
```

</examples>

### Cloudflare AI Gateway

Requires `CLOUDFLARE_ACCOUNT_ID` and `CLOUDFLARE_GATEWAY_ID` env vars.

<examples>

```jsonc
{
  "provider": {
    "cloudflare-ai-gateway": {
      "models": {
        "openai/gpt-5.2": {},
        "anthropic/claude-4-5-sonnet": {}
      }
    }
  }
}
```

</examples>

### Custom Headers (Auth Proxy)

<examples>

```jsonc
{
  "provider": {
    "corp-proxy": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "Corporate Proxy",
      "options": {
        "baseURL": "https://ai-proxy.corp.internal/v1",
        "headers": {
          "X-Corp-Auth": "Bearer ${env:CORP_AI_TOKEN}",
          "X-Team-ID": "engineering"
        }
      },
      "models": {
        "gpt-5.2": { "name": "GPT-5.2 (via proxy)" }
      }
    }
  }
}
```

</examples>

</guidelines>

<rules name="model-options">

## Model Options

### Reasoning / Thinking Modes

Models with reasoning capabilities SHOULD be configured via `variants` to allow cycling modes.

#### Provider-Specific Options

| Provider | Option | Values |
|----------|--------|--------|
| OpenAI/Azure | `reasoningEffort` | `minimal`, `low`, `medium`, `high`, `xhigh` |
| OpenAI/Azure | `reasoningSummary` | `auto`, `detailed` |
| OpenAI/Azure | `include` | `["reasoning.encrypted_content"]` |
| Anthropic | `thinking` | `{ type: "enabled", budgetTokens: number }` |
| Google | `includeThoughts` | boolean |
| Google | `thinkingLevel` | `low`, `high` |
| OpenAI Compatible | `textVerbosity` | `low`, `medium`, `high` |

<examples>

#### Variant Configuration

```jsonc
{
  "variants": {
    "thinking": {
      "reasoningEffort": "high",
      "reasoningSummary": "detailed"
    },
    "instant": {
      "reasoningEffort": "low",
      "textVerbosity": "low"
    }
  }
}
```

#### Anthropic Extended Thinking

```jsonc
{
  "options": {
    "thinking": {
      "type": "enabled",
      "budgetTokens": 32000
    }
  }
}
```

</examples>

### Variant Configuration (Cycle with ctrl+t)

You SHOULD define variants to expose model-specific capabilities like "Thinking" or "Instant" response modes.

<examples>

```jsonc
{
  "variants": {
    "thinking": {
      // OpenAI / Azure / Bedrock
      "reasoningEffort": "high",
      "reasoningSummary": "auto",
      // Anthropic
      "thinking": { "type": "enabled", "budgetTokens": 16000 },
      // Google
      "includeThoughts": true,
      "thinkingLevel": "high"
    },
    "instant": {
      "reasoningEffort": "low",
      "textVerbosity": "low"
    }
  }
}
```

</examples>

</rules>

<constraints name="token-limits">

## Token Limits

Common context window sizes:

| Size | Tokens | Notes |
|------|--------|-------|
| Large | 128,000 | DeepSeek V3.2 |
| XL | 200,000 | Claude 4.5 family |
| XXL | 1,000,000+ | Gemini 3 family |

You MUST verify actual limits from official docs - these change frequently.

</constraints>

</reference>
