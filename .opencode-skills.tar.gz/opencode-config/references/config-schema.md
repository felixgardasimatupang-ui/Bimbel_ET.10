# OpenCode Configuration Schema Reference (Q4 2025)

<reference>

<constraints>
This document defines the schema and valid values for `opencode.json`. You MUST adhere strictly to these definitions. You MUST NOT use deprecated model identifiers.
</constraints>

<constraints name="prohibited-models">

## STRICTLY PROHIBITED MODELS

The following models are DEPRECATED and MUST NOT be used:

| Provider | Prohibited Models |
|----------|-------------------|
| OpenAI | `gpt-4o`, `gpt-4-turbo`, `o1-mini`, `o1-preview` |
| Anthropic | `claude-3-5-sonnet`, `claude-3-opus` |
| Google | `gemini-1.5-pro`, `gemini-2.0-flash` |
| Meta | `llama-3`, `llama-3.1` |

Use current frontier models: **GPT-5.2**, **Claude 4.5**, **Gemini 3**, **GLM-4.7**, **Kimi K2**, **MiniMax M2.1**, **Mistral Large 3**.

</constraints>

<format name="top-level-options">

## Top-Level Options

```jsonc
{
  "$schema": "https://opencode.ai/config.json",

  // Model Configuration
  "model": "provider/model-id",
  "small_model": "provider/model-id",
  "provider": {},
  "disabled_providers": ["openai", "gemini"],

  // UI & Updates
  "theme": "opencode",
  "autoupdate": true,
  "tui": { "scroll_speed": 3 },
  "keybinds": {},

  // Sharing
  "share": "manual", // "manual" | "auto" | "disabled"

  // Tools & Permissions
  "tools": {},
  "permission": {},

  // Agents & Commands
  "agent": {},
  "command": {},

  // Instructions & MCP
  "instructions": [],
  "mcp": {},

  // Formatters
  "formatter": {}
}
```

</format>

<guidelines name="model-configuration">

## Model Configuration

### model / small_model

Format: `provider/model-id`. Run `opencode models` to list available models.

<examples>

```jsonc
{
  "model": "anthropic/claude-4-5-sonnet-20250929",
  "small_model": "anthropic/claude-4-5-haiku-20251015"
}
```

</examples>

### provider

Configure custom providers or override settings:

<examples>

```jsonc
{
  "provider": {
    "anthropic": {
      "models": {},
      "options": {
        "apiKey": "{env:ANTHROPIC_API_KEY}"
      }
    }
  }
}
```

</examples>

### disabled_providers

Prevent providers from loading even if credentials exist:

<examples>

```jsonc
{
  "disabled_providers": ["openai", "gemini"]
}
```

</examples>

</guidelines>

<guidelines name="tools-configuration">

## Tools Configuration

Enable/disable tools globally:

<examples>

```jsonc
{
  "tools": {
    "bash": true,
    "edit": true,
    "write": true,
    "read": true,
    "glob": true,
    "grep": true,
    "list": true,
    "patch": true,
    "webfetch": true,
    "todowrite": true,
    "todoread": true,
    "skill": true
  }
}
```

</examples>

Wildcards supported for MCP tools:

<examples>

```jsonc
{
  "tools": {
    "mymcp_*": false
  }
}
```

</examples>

</guidelines>

<rules name="permissions">

## Permissions

### Simple Permissions

<examples>

```jsonc
{
  "permission": {
    "edit": "allow", // "allow" | "ask" | "deny"
    "webfetch": "ask"
  }
}
```

</examples>

### Pattern-Based Bash Permissions

<examples>

```jsonc
{
  "permission": {
    "bash": {
      "*": "allow",           // Default for all
      "rm *": "ask",          // Ask before delete
      "rm -rf *": "deny",     // Block recursive delete
      "sudo *": "deny",       // Block sudo
      "git push": "ask",      // Ask before push
      "npm run *": "allow"    // Allow npm scripts
    }
  }
}
```

</examples>

### Skill Permissions

<examples>

```jsonc
{
  "permission": {
    "skill": {
      "*": "allow",
      "dangerous-*": "deny",
      "experimental-*": "ask"
    }
  }
}
```

</examples>

</rules>

<guidelines name="agent-configuration">

## Agent Configuration

Define agents in config:

<examples>

```jsonc
{
  "agent": {
    "my-agent": {
      "description": "What triggers this agent",
      "mode": "subagent",
      "model": "anthropic/claude-4-5-sonnet-20250929",
      "prompt": "System prompt or {file:./prompt.txt}",
      "temperature": 0.3,
      "maxSteps": 25,
      "disable": false,
      "tools": {
        "bash": false
      },
      "permission": {
        "edit": "ask"
      }
    }
  }
}
```

</examples>

</guidelines>

<guidelines name="commands">

## Commands

Custom slash commands. Use `$ARGUMENTS` for user input after command.

<examples>

```jsonc
{
  "command": {
    "test": {
      "template": "Run tests and show failures. $ARGUMENTS",
      "description": "Run test suite",
      "agent": "build",
      "model": "anthropic/claude-4-5-sonnet-20250929"
    }
  }
}
```

</examples>

</guidelines>

<guidelines name="instructions">

## Instructions

Include additional instruction files. Supports glob patterns.

<examples>

```jsonc
{
  "instructions": [
    "CONTRIBUTING.md",
    "docs/guidelines.md",
    ".cursor/rules/*.md",
    "packages/*/AGENTS.md"
  ]
}
```

</examples>

</guidelines>

<guidelines name="formatters">

## Formatters

Configure code formatters:

<examples>

```jsonc
{
  "formatter": {
    "prettier": {
      "disabled": true
    },
    "custom": {
      "command": ["npx", "prettier", "--write", "$FILE"],
      "environment": { "NODE_ENV": "development" },
      "extensions": [".js", ".ts", ".jsx", ".tsx"]
    }
  }
}
```

</examples>

</guidelines>

<guidelines name="mcp-servers">

## MCP Servers

Configure Model Context Protocol servers:

<examples>

```jsonc
{
  "mcp": {
    "my-server": {
      "type": "local",
      "command": ["npx", "-y", "@org/package"],
      "environment": { "KEY": "VALUE" }
    },
    "remote-name": {
      "type": "remote",
      "url": "https://api.example.com/mcp",
      "headers": { "Authorization": "Bearer ..." }
    }
  }
}
```

</examples>

</guidelines>

<rules name="model-variants">

## Model Variants (ctrl+t)

Variants allow you to define multiple parameter sets for a single model, cycleable via `ctrl+t`.

<examples>

```jsonc
{
  "provider": {
    "openai": {
      "models": {
        "gpt-5.2": {
          "variants": {
            "high": {
              "reasoningEffort": "high",
              "reasoningSummary": "detailed"
            },
            "low": {
              "reasoningEffort": "low",
              "textVerbosity": "low"
            }
          }
        }
      }
    }
  }
}
```

</examples>

### Functional Variant Properties

| Property | Provider | Values |
|----------|----------|--------|
| `reasoningEffort` | OpenAI/Azure | `minimal`, `low`, `medium`, `high`, `xhigh` |
| `reasoningSummary` | OpenAI/Azure | `auto`, `detailed` |
| `textVerbosity` | OpenAI Compatible | `low`, `medium`, `high` |
| `thinking` | Anthropic | `{ type: "enabled", budgetTokens: number }` |
| `thinkingLevel` | Google | `low`, `high` |
| `include` | OpenAI/Azure | `["reasoning.encrypted_content"]` |

</rules>

<guidelines name="variable-substitution">

## Variable Substitution

### Environment Variables

<examples>

```jsonc
{
  "model": "{env:OPENCODE_MODEL}",
  "provider": {
    "openai": {
      "options": {
        "apiKey": "{env:OPENAI_API_KEY}"
      }
    }
  }
}
```

</examples>

### File Contents

<examples>

```jsonc
{
  "agent": {
    "custom": {
      "prompt": "{file:./prompts/custom.txt}"
    }
  },
  "provider": {
    "anthropic": {
      "options": {
        "apiKey": "{file:~/.secrets/anthropic-key}"
      }
    }
  }
}
```

</examples>

</guidelines>

<guidelines name="misc-options">

## Miscellaneous Options

### TUI Options

<examples>

```jsonc
{
  "tui": {
    "scroll_speed": 3
  }
}
```

</examples>

### Sharing Options

| Value | Description |
|-------|-------------|
| `manual` | Share via `/share` command (default) |
| `auto` | Auto-share new conversations |
| `disabled` | No sharing |

<examples>

```jsonc
{
  "share": "manual"
}
```

</examples>

</guidelines>

</reference>
