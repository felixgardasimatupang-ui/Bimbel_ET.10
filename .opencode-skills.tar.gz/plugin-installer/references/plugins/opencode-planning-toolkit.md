---
name: "@howaboua/opencode-planning-toolkit"
description: Shared repo todo planning toolkit for OpenCode sessions
---

<reference id="opencode-planning-toolkit">

# @howaboua/opencode-planning-toolkit

**Package:** `@howaboua/opencode-planning-toolkit`
**Author:** howaboua
**Latest Version:** Check npm

<guidelines>

## Purpose

Adds a planning toolkit so humans and agents can share a repo-level todo plan and keep long-running coding sessions aligned.

## Features

- Shared todo/planning flow across sessions
- Better task continuity between agent handoffs
- Structured planning workflow for multi-step development

</guidelines>

<rules>
<installation>

## Installation

```jsonc
{
  "plugin": ["@howaboua/opencode-planning-toolkit@latest"]
}
```

</installation>

<configuration>

## Configuration

No required plugin-specific config documented; install in `plugin` array.

</configuration>
</rules>

<examples>

## Usage

Use when you want explicit planning and todo continuity in OpenCode sessions.

## Updating

```bash
opencode --update
```

</examples>

<constraints>

## Caveats

- Behavior depends on plugin version and OpenCode runtime compatibility.
- Verify plugin docs for any new setup requirements.

</constraints>

<links>
- [npm](https://www.npmjs.com/package/@howaboua/opencode-planning-toolkit)
- [GitHub](https://github.com/IgorWarzocha/opencode-planning-toolkit)
</links>

</reference>
