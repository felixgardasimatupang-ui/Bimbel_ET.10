---
name: "@tarquinen/opencode-dcp"
description: Dynamic Context Pruning - reduce tokens by removing obsolete tool outputs
---

<reference id="opencode-dcp">

# @tarquinen/opencode-dcp

**Package:** `@tarquinen/opencode-dcp`
**Author:** Dan Tarquinen
**Latest Version:** 1.0.4

<guidelines>

## Purpose

Dynamic Context Pruning - automatically reduces token usage by removing obsolete tool outputs from conversation history.

## Features

- **Deduplication:** Identifies repeated tool calls, keeps only most recent output (zero LLM cost)
- **Supersede Writes:** Prunes write tool inputs for files that were later read (zero LLM cost)
- **Prune Tool:** AI can manually trigger pruning when needed
- **On Idle Analysis:** LLM analyzes context during idle periods to find irrelevant outputs

Session history is never modified - pruned outputs replaced with placeholder before sending to LLM.

</guidelines>

<rules>
<installation>

## Installation

```jsonc
{
  "plugin": ["@tarquinen/opencode-dcp@latest"]
}
```

</installation>

<configuration>

## Configuration

**Config file locations:**
- Global: `~/.config/opencode/dcp.jsonc` (auto-created on first run)
- Custom: `$OPENCODE_CONFIG_DIR/dcp.jsonc`
- Project: `.opencode/dcp.jsonc`

**Precedence:** Defaults → Global → Config Dir → Project

### Example Config

```jsonc
{
  "deduplication": {
    "enabled": true,
    "protectedTools": []
  },
  "supersedeWrites": {
    "enabled": true
  },
  "pruneTool": {
    "enabled": true
  },
  "onIdleAnalysis": {
    "enabled": false,
    "idleThresholdMs": 30000
  }
}
```

</configuration>

<protected-tools>

## Protected Tools

These tools MUST NOT be pruned:
- `task`
- `todowrite`
- `todoread`
- `prune`
- `batch`

You MAY add more via `protectedTools` arrays in each strategy.

</protected-tools>
</rules>

<constraints>

## Trade-offs

**Prompt Caching Impact:**
Pruning changes message content, which invalidates cached prefixes. You lose some cache read benefits but gain larger token savings from reduced context size.

In most cases, token savings outweigh cache miss cost - especially in long sessions.

## Caveats

- You MUST restart OpenCode after config changes
- Does not modify actual session history
- On Idle Analysis uses LLM calls (has cost)

</constraints>

<links>
- [npm](https://www.npmjs.com/package/@tarquinen/opencode-dcp)
- [GitHub](https://github.com/Tarquinen/opencode-dynamic-context-pruning)
</links>

</reference>
